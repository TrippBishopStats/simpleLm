# simpleLm
a simple linear regression package for R
